#include<iostream>
#include<fstream>
#include<conio.h>
#include<string.h>

using namespace std;
class Person
{
protected:
string name;
string email;
long int phone;
public:
Person()
{
    name=" ";
    email=" ";
    phone=00;
}
Person(string name, string email,long int phone)
{
   this->name=name;
    this->email=email;
    this->phone=phone;
}
string getname()
{
    return name;
}

string getemail()
{
    return email;
}

long int getphone()
{
    return phone;
}

};
class customer:public Person                                 //customer class
{
 protected:

int d;                                         //days
int m;                                         //month
int y;                                          //year
 public:
 char slash;                                    //date separator
 customer()                                        //class of customer
 {
    d=0;
    m=0;
    y=0;
     slash='0';
 }
 customer(char name[30], string email, long int phone,int d,int m,int y):Person(name,email,phone)
 {
        this->d=d;
        this->m=m;
        this->y=y;
        this->slash=slash;
 }

 void reservation()                               //These details are for reservation
 {                                             
system("cls");
     cout<<"\nName:\t";
     cin.ignore();
   getline(cin,name);
     cout<<"Contact:\t";
     cin>>phone;
     if(phone>00)
     {
     cout<<"Email:\t";
     cin>>email;
     }
else{
  throw runtime_error("INVALID INPUT");                           //exp handling
}
    cout<<"Reservation Date:\t";
	cin>>d>>slash>>m>>slash>>y;

	if(d==0||d>31||m==0||m>12||y==0||slash!='/')
    {
        cout<<"\n\t\t\t\tInvalid Date! format(dd/mm/yy)!\n"<<endl;
    
    }

     fstream file;
    file.open("customer_details.txt",ios::app|ios::out);
    file<<"\nName:\t"<<getname()<<endl
    <<"Contact:\t"<<getphone()<<endl
    <<"Email:\t"<<getemail()<<endl
   <<"Reservation Date:\t"<<d<<slash<<m<<slash<<y<<endl;
    file.close();
 }
};


class order                                              //order details
{
   float total=0;
    
    public:
    int order_id;
     float gt=0;
   int price;

    order()
    {
        order_id=0;
        total=0.0;
    }
    order(int oid,float t)
    {
        this->order_id=oid;
        this->total=t;
    }
    void setoid(int oid)
    {
        this->order_id=oid;
    }
    int getoid()
    {
        return order_id;
    }
    void sett(float t)
    {
        this->total=t;
    }
      int gett()
    {
        return total;
    }
    void setgt(float t)
    {
        this->gt=t;
    }
  
     int getgt()
    {
        return gt;
    }
    void main_menu()                                              //main cusine
    {
      cout<<"\n--------------------------------------------------------"<<endl;
        cout<<"\n\t\t\tBURGERS\t\t\t";
        setoid(1223);
      cout<<getoid()<<endl;
       cout<<"--------------------------------------------------------"<<endl;
       cout<<"1- Aaloo Tikki Burger                          "<<69<<"/-"<<endl
           <<"2- Corn Cheese Burger                          "<<99<<"/-"<<endl
           <<"3- Double Tikki Cheese burger                  "<<119<<"/-"<<endl;
       cout<<"--------------------------------------------------------"<<endl;

      cout<<"\n\t\t\tSMALL BITES\t\t";
      setoid(1224);
      cout<<getoid()<<endl;
         cout<<"--------------------------------------------------------"<<endl;
      cout<<"4- Veg Balls (10pcs.)                          "<<129<<"/-"<<endl
          <<"5- Corn Cheese Nugets (10pcs.)                 "<<109<<"/-"<<endl
          <<"6- Smileys                                     "<<99<<"/-"<<endl;
         cout<<"--------------------------------------------------------"<<endl;

      cout<<"\n\t\t\tPATTIES\t\t\t";
       setoid(1225);
      cout<<getoid()<<endl;
         cout<<"--------------------------------------------------------"<<endl;
         cout<<"7- Veg Patty                                   "<<59<<"/-"<<endl
             <<"8- Veg Corn Patty                              "<<69<<"/-"<<endl
             <<"9- Paneer Patty                                "<<79<<"/-"<<endl;
         cout<<"--------------------------------------------------------"<<endl;

      cout<<"\n\t\t\tWRAPS\t\t\t";
       setoid(1225);
      cout<<getoid()<<endl;
         cout<<"--------------------------------------------------------"<<endl;
          cout<<"10- Standard Wrap                               "<<79<<"/-"<<endl
              <<"11- Spicy Cheese Wrap                           "<<79<<"/-"<<endl
              <<"12- Lava Paneer Wrap                            "<<89<<"/-"<<endl;
         cout<<"--------------------------------------------------------"<<endl;

      cout<<"\n\t\t\tSANDWICH\t\t";
       setoid(1226);
      cout<<getoid()<<endl;
         cout<<"--------------------------------------------------------"<<endl;
         cout<<"13- Veg Grilled Sandwich                        "<<129<<"/-"<<endl
             <<"14- Green Sandwich                              "<<139<<"/-"<<endl
             <<"15- Veg Corn Cheese Sandwich                    "<<149<<"/-"<<endl;
         cout<<"--------------------------------------------------------"<<endl;

      cout<<"\n\t\t\tSWEET CORNS\t\t";
       setoid(1227);
      cout<<getoid()<<endl;
         cout<<"--------------------------------------------------------"<<endl;
          cout<<"16- Sweet Corns                                 "<<79<<"/-"<<endl
             <<"17- Spicy Corns                                 "<<89<<"/-"<<endl
             <<"18- Spicy Corns                                 "<<99<<"/-"<<endl;
         cout<<"--------------------------------------------------------"<<endl;

      cout<<"\n\t\t\tPASTA'S\t\t\t";
       setoid(1228);
      cout<<getoid()<<endl;
         cout<<"--------------------------------------------------------"<<endl;
          cout<<"19- Red Sauce Pasta                             "<<169<<"/-"<<endl
              <<"20- Makhni Pasta                                "<<169<<"/-"<<endl
              <<"21- White Sauce Pasta                           "<<179<<"/-"<<endl;
         cout<<"--------------------------------------------------------"<<endl;

      cout<<"\n\t\t\tFRIES\t\t\t";
       setoid(1229);
      cout<<getoid()<<endl;
         cout<<"--------------------------------------------------------"<<endl;
          cout<<"22- French Fries                                "<<129<<"/-"<<endl
              <<"23- Masala Fries                                "<<139<<"/-"<<endl
              <<"24- Cheese Fries                                "<<59<<"/-"<<endl;
         cout<<"--------------------------------------------------------"<<endl;

      cout<<"\n\t\t\tBEVARAGES\t\t";
       setoid(12210);
      cout<<getoid()<<endl;
         cout<<"--------------------------------------------------------"<<endl;
           cout<<"25- Fresh Lime Soda                             "<<69<<"/-"<<endl
               <<"26-Lemon Ice Tea                               "<<79<<"/-"<<endl
               <<"27-Peach Ice Tea                               "<<89<<"/-"<<endl;
         cout<<"--------------------------------------------------------"<<endl;

      cout<<"\n\t\t\tDESERTS\t\t\t";
       setoid(12211);
      cout<<getoid()<<endl;
         cout<<"--------------------------------------------------------"<<endl;
          cout<<"28- Brownie with Icecream                       "<<149<<"/-"<<endl
              <<"29- Brownie Chocolate Sauce                     "<<139<<"/-"<<endl
              <<"30- Choco Lava Cake                             "<<179<<"/-"<<endl;
         cout<<"--------------------------------------------------------"<<endl;
       cout<<"\nSelect Deal:\t";
      
    }
    void calculate()                                    
{
   main_menu();
     int x;
      char d;
      b:
      int deal;
      cin>>deal; 
      if(deal >= 1 && deal <= 30)
    { 
  do{
    
      switch (deal)
      {
      case 1:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=69;
      total=price*x;
        sett(total);
       cout<<gett()<<"/-"<<endl;
     gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
      
          goto b;
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                        //exp handling
  }
  break;
      case 2:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=99;
      total=price*x;
      sett(total);
     
      cout << gett() << "/-" << endl;
       gt+=total;
      cout << "\n\t\t\tDo you want another item (y/n)?\t";
      cin >> d;

      if (d == 'y')
      {
    cout << "\nSelect Deal:\t";

    goto b;
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                           //exp handling
  }
    break;
      case 3:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=119;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
      
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
         
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                       //exp handling
  } 
break;
        case 4:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=129;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
     if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
         
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                           //exp handling
  }
break;
        case 5:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=109;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
      if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
         
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                       //exp handling
  }
break;
        case 6:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=99;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
   if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
       
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                             //exp handling
  }
break;
        case 7:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=59;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
      if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
         
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                              //exp handling
  }
break;
        case 8:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=69;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
     if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
      
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                            //exp handling
  }
break;
        case 9:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=79;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
      
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                           //exp handling
  }
break;
        case 10:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=79;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
         
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                             //exp handling
  }
break;
        case 11:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=79;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
        if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
    
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                             //exp handling
  }
break;
        case 12:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=89;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
        if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
     
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                           //exp handling
  }
       break;
        case 13:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=129;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
       
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                      //exp handling
  }
break;
        case 14:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=139;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
        
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                         //exp handling
  }
break;
        case 15:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=149;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
      if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
        
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                                   //exp handling
  }
break;
        case 16:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=79;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
      if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
        
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                                  //exp handling
  }
break;
        case 17:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=89;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
        if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
        
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                                       //exp handling
  }
break;
        case 18:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=99;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
       
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                                //exp handling
  }
break;
        case 19:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=169;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
        if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
        
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                                     //exp handling
  }
break;
        case 20:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=169;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
     
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                                      //exp handling
  }
break;
        case 21:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=179;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
      
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                                  //exp handling
  }
break;
        case 22:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=129;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
        if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
   
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                            //exp handling
  }
break;
        case 23:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=139;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
        if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
    
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                               //exp handling
  }
break;
        case 24:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=59;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
        
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                        //exp handling
  }
break;
        case 25:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=69;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
        if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
     
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                         //exp handling
  }
break;
        case 26:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=79;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
     
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                        //exp handling
  }
break;
        case 27:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=89;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
        if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                      //exp handling
  }
break;
        case 28:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=149;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
        if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
     
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");                         //exp handling
  }
break;
        case 29:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=139;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
       if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
  
       }
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");             //exp handling
  }
break;
        case 30:
      cout<<"\nQuantity=\t";
        cin>>x;
      price=179;
      total=price*x;
      sett(total);
       cout<<gett()<<"/-"<<endl;
        gt+=total;
       cout<<"\n\t\t\tDo you want another item (y/n)?\t";
       cin>>d;
      if(d=='y')
       {
         cout<<"\nSelect Deal:\t";
        
         goto b;
    
       }
    
        else if(d!='n'){
    throw runtime_error("\n\t\tINVALID INPUT");
  }
break;

      default:
      cout<<"\n\t\t\t\t\t////// Invalid Input! //////\n\n";
        break;
      }

      }while (d=='y');
  }
  else{
    throw runtime_error("\n\t\tINVALID INPUT");
  }
         float tax,get;
      cout<<"\nTotal Bill=\t"<<gett()<<endl;
        tax=0.15;
        cout<<"Tax=\t"<<tax<<endl;
        cout<<"--------------------------------------------------------"<<endl;
        get=gt+tax;
        setgt(get);
        cout<<"\nTotal Bill + Tax=\t"<<getgt()<<"/-"<<endl;
         
    }
                                                             //end of calculation
    
};                                                      //end of order class
 
class waiter
{
    public:

void login()
    {
      cout<<"\n\n\t\t\t\tWELCOME TO LOG IN ZONE";
      cout<<"\n\t\t\t\t^^^^^^^^^^^^^^^^^^^^^^";
      for(int i=0;i<1000;i++)                                         //check username and password char by char
      {
        
      FILE *log;                                              //pointer type file
      char c,name[30],pass[30]; int z=0;
   
      log=fopen("login_details.txt","rb");                          //file open
        cout<<"\n\n\t\t\t\t  ENTER USERNAME: ";
       cin.ignore();
      cin.getline(name,30);
        cout<<"\n\n\t\t\t\t  ENTER PASSWORD: ";
        while((c=getch())!=13)
        {
          pass[z++]=c;
          cout<<"*";
        }
        pass[z]='\0';
      while(!feof(log))                                                     //check file until the end
        {
        fread(&log,sizeof(log),1,log);                              //fread()=read data from file
          if(name==name&& pass==pass)
          {
            cout<<"\n\n\n\t\t\t\t\tYOU HAVE LOGGED IN SUCCESSFULLY!!";
             cout<<"\n\n\n\t\t\t\t//////// Order Created on System! ////////\n\n";
           
            break;
          }
        else
          {
            cout<<"\n\n\n\t\t\tWRONG PASSWORD!! Not "<<name<<"??";
           cout<<"\n\n\t\t\t\t  (Press 'Y' to re-login)";
            if(getch()=='y'||getch()=='Y')
              login();
              break;
          }
        }
        break;
      }
      getch();
    }
       
void takeorder()                                                           //waiter taskes order
{

  int x;
    do{
      if(x > 0 || x< 18)
   {
         system("cls");
         order o;
       cout<<"\nTable: 1-17"<<endl;
       cout<<"Take order from:\t";
       cin>>x;  
       if(x>= 1 && x<= 17)
       {
          cout<<"\n\nPlease Enter Your Name: ";
          char name[20];
          cin.ignore();
	    cin.getline(name,20);
	   cout<<"\n\t\tHello "<<name<<"!";
            cout<<"\n\n\t\tWhat would you like to eat!"<<endl;
                 o.calculate();                                //show menu items
              fstream file;
           file.open("Total_Bill.txt",ios::app|ios::out);
           file<<"\n\nTotal Bill of table:\t"<<x<<endl
           <<o.getgt();
            file.close();
         login();
         cout<<"\n\n\t\t\t\t//// Wait for your order to be served! ////\n"<<endl;
         system("cls");
         break;
       }
      else{
        cout<<"INVALID INPUT";
      }
   }
      else{
    throw runtime_error("\n\t\tINVALID INPUT");

  }
      
    }while(x<1 || x>17);
   }
};                                                                 //waiter class ends


int main()
{
   string x;
   char ch;
   a:
   do{
        system("cls");
       cout<<"\t\t\t\t|^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^|\n";
    	 cout<<"\t\t\t\t|                   WELCOME TO SIP & DIP                |\n";
	     cout<<"\t\t\t\t|^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^|\n\n";
  
    
    cout<<"\n\t\t1- Place Order\n";
    cout<<"\t\t2- Make a reservation\n";
    cout<<"Select:\t";
    cin>>x;
  if(x=="1")
  {
    waiter w;
    w.takeorder();

order order;
   int gn;
   cout<<"\n\n\t\t\t\tCan you pay the bill in cash press 1?"<<endl;
cin>>gn;
      if(gn==1)
        {
        cout<<"Pay the Total bill on counter "<<endl;
          cout<<"\n\n\t\t\t\t^^^^^^^^^^^^^^ Thanks for visiting SIP & DIP!!! ^^^^^^^^^^^^^^\n\n";
         
      }

   cout<<"\n\t\tBACK TO MAIN (y/n):\t";
          cin>>ch;
          if(ch=='y')
          {
            true;
            goto a;
          }
break;
  }
 else if(x=="2")
  {
     customer c;
     c.reservation();
         cout<<"\nPay 1000/- for pre-booking\n";
         cout<< "\n\n\t\t\t\t\tHow would you like to pay Sir/Mam!";
order o;
   
   cout<<"\n\n\t\t\t\tyou can pay the bill 1:ATM card  2:cash?"<<endl;

      int gn;
      cin>>gn;
        int amount;
      if(gn==1)
      {
        cout<<"\nPlease scarach the card on machine and entered the details"<<endl;
b:
        cout<<"\nenter the pin:\t"<<endl;
        int pin;
        cin>>pin;
        if(pin>0)
        {
        string strpin=to_string(pin);
        if(strpin>="0")
        {
        int len=strpin.length();
        if(len!=4)
        {
          cout<<"\n\t\t\t\t\t////// Invalid Pin! //////\n\n";
          goto b;
        }
        }
        }
         else
        {
          throw runtime_error("INVALID INPUT");                    //exp handling
        }
      
        o.sett(1000);
        cout<<"Transfered amount:"<< o.gett()<<endl;
          cout<<"\n\n\t\t\t\t///////////////// Your table has been Reserved!! //////////////////\n";
        cout<<"\n\n\t\t\t\t^^^^^^^^^^^^^^^^ Thanks for visiting SIP & DIP!!! ^^^^^^^^^^^^^^^\n\n";
         cout<<"\n\t\tBACK TO MAIN (y/n):\t";
          cin>>ch;
          if(ch=='y')
          {
            true;
            goto a;
          }
          else{
    throw runtime_error("\n\t\tINVALID INPUT");                            //exp handling
  }
        }
else if(gn==2)
        {
        cout<<"Pay the cash bill on counter "<<endl;
         o.sett(1000);
         cout<< o.gett();
           cout<<"\n\n\t\t\t\t///////////////// Your table has been Reserved!! //////////////////\n";
          cout<<"\n\n\t\t\t\t^^^^^^^^^^^^^^ Thanks for visiting SIP & DIP!!! ^^^^^^^^^^^^^^\n\n";
          cout<<"\n\t\tBACK TO MAIN (y/n):\t";
          cin>>ch;
          if(ch=='y')
          {
            true;
            goto a;
          }
          else{
    throw runtime_error("\n\t\tINVALID INPUT");                                 //exp handling
  }
      }
      else{
    throw runtime_error("\n\t\tINVALID INPUT");                                //exp handling
  }
break;

  }

cout<<"\n\t\t\t\t\t////// Invalid Input! //////\n\n";

    }while(x!="1" || x!="2");


return 0;
}