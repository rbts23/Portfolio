<!-- http://localhost/website/website.php -->
<!Doctype html>
<head>
<body>
 <title>3M Associates Database Management</title>
   <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #d1f0f1;
        }
    </style>
    <link rel="stylesheet" type="text/css" href="style.css">

<body>
    <h1>3M Associates Database Management</h1>
<?php
$servername = "localhost";
$username = "admin";
$password = "rijabbutt";
$dbname = "website";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to insert a new project

if (isset($_POST['insert_project'])){
    
    $project_id = $_POST['project_id'];
    $clientId = $_POST['client_id'];
    $client_name = $_POST['client_name'];
    $client_num = $_POST['client_num'];
    $email = $_POST['email'];
    $proj_name = $_POST['proj_name'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $status = $_POST['status'];
    $location = $_POST['location'];

    $sqlproject = ("INSERT INTO `projects`(`project_id`, `client_id`, `client_name`,`client_num`, `email`, `proj_name`, `start_date`, `end_date`, `status`, `location`) VALUES ($project_id, $clientId, '".$client_name."','".$client_num."','".$email."','".$proj_name."', '".$start_date."', '".$end_date."', '".$status."', '".$location."')");

    if ($conn->query($sqlproject) === TRUE) {
    echo "New Project created successfully";
    } else {
    echo "Error: " . $sqlproject . "<br>" . $conn->error;
    }
}


if (isset($_POST['insert_invoice'])){
    
    $project_id_invoice = $_POST['project_id'];
    $amount_invoice = $_POST['amount'];

    $sqlinvoices = ("INSERT INTO `invoices`(`project_id`, `amount`) VALUES ($project_id_invoice, '".$amount_invoice."')");

    if ($conn->query($sqlinvoices) === TRUE) {
    echo "New Invoice created successfully";
    } else {
    echo "Error: " . $sqlinvoices . "<br>" . $conn->error;
    }
}


if (isset($_POST['insert_employee'])) {

    // Fetch the highest employee_id from the employees table
    $query = "SELECT MAX(employee_id) AS max_id FROM employees";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
    $highest_id = $row['max_id'];

    // Increment the highest employee_id by one
    $new_employee_id = $highest_id + 1;
    $employee_fullname = $_POST['employee_name'];
    $employee_num = $_POST['emp_num'];
    $employee_position = $_POST['position'];

    // Insert the new employee record into the employees table
    $sqlemployees = "INSERT INTO employees (`employee_id`, `employee_name`,`emp_num`, `position`)
    VALUES ($new_employee_id,'$employee_fullname','$employee_num', '$employee_position')";      
    if ($conn->query($sqlemployees) === TRUE) {
        
        echo "New Employee created successfully<br><br>";
    }
 else {
    echo "Error: " . $sqlemployees . "<br>" . $conn->error;
    }
}

// Function to delete project by project_id
function deleteProject($project_id, $conn) {

    // Delete from invoices table
    $delete_invoices_query = "DELETE FROM invoices WHERE project_id = '$project_id'";
    $conn->query($delete_invoices_query);

    // Delete from projects table
    $delete_projects_query = "DELETE FROM projects WHERE project_id = '$project_id'";
    $conn->query($delete_projects_query);
    // Check if any rows were affected in both tables
    if ($conn->affected_rows >= 1) {
        echo "Project with project_id '$project_id' deleted successfully.";
    } 
    else{
        echo "No project found!";
    }
}

// Handle form submission
if (isset($_POST['delete_project'])) {
    $project_id_to_delete = $_POST['project_id'];
    deleteProject($project_id_to_delete, $conn);
}


// Function to search and retrieve results
function searchProject($search_query, $conn) {
    $search_query = mysqli_real_escape_string($conn, $search_query);
    $query = "SELECT projects.*, invoices.amount
              FROM projects
              LEFT JOIN invoices ON projects.project_id = invoices.project_id
              WHERE projects.project_id LIKE '%{$search_query}%' OR projects.client_name LIKE '%{$search_query}%'";
    $result = $conn->query($query);
    $results = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }
    }
    return $results;
}

// Handle form srch_invoice
if (isset($_POST['srch_invoice'])) {
    $search_query = $_POST['id_srch_invoice'];
    $results = searchProject($search_query, $conn);
}


  // Generate budget report
    if (isset($_POST['generate_budget_report'])) {
        $query = "SELECT client_name,client_num, projects.project_id, projects.proj_name, SUM(invoices.amount) AS total_budget
                  FROM projects
                  LEFT JOIN invoices ON projects.project_id = invoices.project_id
                  GROUP BY projects.project_id";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            echo "<h2>Budget Report</h2>";
            echo "<table>";
            echo "<tr style='text-align: center;'>
                    <th>Project ID</th>
                    <th>Client Name</th>
                    <th>Contact No.</th>
                    <th>Project Name</th>
                    <th>Total Budget</th>
                </tr>";

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr style='text-align: center;'>";
                echo "<td>" . $row['project_id'] . "</td>";
                echo "<td>" . $row['client_name'] . "</td>";
                echo "<td>" . $row['client_num'] . "</td>";
                echo "<td>" . $row['proj_name'] . "</td>";
             $formattedAmount = number_format($row['total_budget'], 0, ',', ',');
                echo "<td>" . $formattedAmount . "</td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "No projects found.";
        }
    }

    // Generate timeline report
    if (isset($_POST['generate_timeline_report'])) {
        $query = "SELECT client_name,client_num, proj_name, start_date, end_date FROM projects";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            echo "<h2>Timeline Report</h2>";
            echo "<table>";
            echo "<tr style='text-align: center;'>
                    <th>Client Name</th>
                    <th>Client Num</th>
                    <th>Project Name</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    </tr>";

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr style='text-align: center;'>";
                echo "<td>" . $row['client_name'] . "</td>";
                echo "<td>" . $row['client_num'] . "</td>";
                echo "<td>" . $row['proj_name'] . "</td>";
                echo "<td>" . $row['start_date'] . "</td>";
                echo "<td>" . $row['end_date'] . "</td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "No projects found.";
        }
    }


    ?>