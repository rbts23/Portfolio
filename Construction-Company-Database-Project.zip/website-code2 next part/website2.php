 <h2>Project Display</h2>
    <table>
        <thead>
            <tr>
                <th>Project ID</th>
                <th>Client ID</th>
                <th>Client Name</th>
                <th>Contact No.</th>
                <th>Email</th>
                <th>Project Name</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Location</th>
                <th>Budget</th>
            </tr>
        </thead>
        <tbody>

  <?php
$query = "SELECT projects.*, SUM(invoices.amount) AS total_budget
          FROM projects 
          LEFT JOIN invoices ON projects.project_id = invoices.project_id";
$result = $conn->query($query);

if ($result === false) {
    echo "Error executing the query: " . $conn->error;
} else {
    $previousProjectId = null;
    $previousInvoice=null;
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $projectId = $row['project_id'];

            if ($projectId !== $previousProjectId) {
                echo "<tr style='text-align: center;'>";
                echo "<td>" . $projectId . "</td>";
                echo "<td>" . $row['client_id'] . "</td>";
                echo "<td>" . $row['client_name'] . "</td>";
                echo "<td>" . $row['client_num'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
                echo "<td>" . $row['proj_name'] . "</td>";
                echo "<td>" . $row['start_date'] . "</td>";
                echo "<td>" . $row['end_date'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "<td>" . $row['location'] . "</td>";

                $invoiceAmount = $row['total_budget'];
                if ($invoiceAmount !== null or $invoiceAmount!== $previousInvoice) {
                    $formattedAmount = number_format($invoiceAmount, 0, ',', ',');
                    echo "<td>" . $formattedAmount . "</td>";
                } else {
                    echo "<td>No Budget</td>";
                }

                echo "</tr>";
            }

        }
    } else {
        echo "0 results";
    }
}


?>

        </tbody>
    </table>

    <div class="container">

        <h2>Insert Project</h2>
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input type="number" name="project_id" placeholder="Project ID" required>
            <input type="text" name="proj_name" placeholder="Project Name" required>
            <input type="number" name="client_id" placeholder="Client ID" required>
            <input type="text" name="client_name" placeholder="Client Name" required>
            <input type="number" name="client_num" placeholder="Contact No." required>
            <input type="text" name="email" placeholder="Client Email" required>
            <input type="date" name="start_date" required>
            <input type="date" name="end_date" required>
            <input type="text" name="status" placeholder="Status" required>
            <input type="text" name="location" placeholder="Location" required>
            <input type="submit" name="insert_project" value="Insert">
        </form>
    </div>
    <div class="container">

        <h2>Add Invoice</h2>
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input type="number" name="project_id" placeholder="Project ID" required>
            <input type="text" name="amount" placeholder="Amount" required>
            <input type="submit" name="insert_invoice" value="Insert">
        </form>
    </div>


    <div class="container">

        <h2>Delete Project</h2>
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input type="number" name="project_id" placeholder="Project ID" required>
            <input type="submit" name="delete_project" value="Delete">
        </form>
    </div>

    <div class="container">

        <h3>Search Projects</h3>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        <input type="text" name="id_srch_invoice" placeholder="Enter project name or location">
        <input type="submit" name="srch_invoice" value="Search">
    </form>

    <?php if (isset($results) && !empty($results)) : ?>
        <h3>Search Results</h3>
        <table>
            <tr style='text-align: center;'>
                <th>Project ID</th>
                <th>Client ID</th>
                <th>Client Name</th>
                <th>Contact No.</th>
                <th>Email</th>
                <th>Project Name</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Location</th>
                <th>Budget</th>
            </tr>
            <?php foreach ($results  as $project) : ?>
                <tr style='text-align: center;'>
                    <td><?php echo $project['project_id']; ?></td>
                    <td><?php echo $project['client_id']; ?></td>
                    <td><?php echo $project['client_name']; ?></td>
                    <td><?php echo $project['client_num']; ?></td>
                    <td><?php echo $project['email']; ?></td>
                    <td><?php echo $project['proj_name']; ?></td>
                    <td><?php echo $project['start_date']; ?></td>
                    <td><?php echo $project['end_date']; ?></td>
                    <td><?php echo $project['status']; ?></td>
                    <td><?php echo $project['location']; ?></td>
                    <? $formattedAmount = number_format($row['amount'], 0, ',', ','); ?>
                    <td><?php echo $formattedAmount ; ?></td>
                </tr>   
                <?php endforeach; ?>
        </table>
        <?php else: ?>
            <p>No results found.</p>
        <?php endif; ?>
    </div>

</body>
</html>

 <h2>Generate Budget Report</h2>
    <form method="POST" action="">
        <input type="submit" name="generate_budget_report" value="Generate Budget Report">
    </form>

    <h2>Generate Timeline Report</h2>
    <form method="POST" action="">
        <input type="submit" name="generate_timeline_report" value="Generate Timeline Report">
    </form>

 <h2>Employees</h2>
<table>
 <tbody>
      <?php
         // Fetch and display all employee data from the employees table
        $query = "SELECT * FROM employees";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Employee ID</th><th>Employee Name</th><th>Employee No.</th><th>Position</th></tr>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['employee_id'] . "</td>";
                echo "<td>" . $row['employee_name'] . "</td>";
                echo "<td>" . $row['emp_num'] . "</td>";
                echo "<td>" . $row['position'] . "</td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "No employees found.";
        }
        ?>
        </tbody>
    </table>

<div class="container">

    <h2>Add Employee</h2>
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="text" name="employee_name" placeholder="Name" required>
        <input type="number" name="emp_num" placeholder="Contact No." required>
        <input type="text" name="position" placeholder="Position" required>
        <input type="submit" name="insert_employee" value="Add Employee">
    </form>
    </div>
     </body>
     </head>

     
<?php
// Close the database connection
$conn->close();
?>