import random

HUMAN = -1
COMP = 1
board = [0] * 9

               # Evaluate the current state of the board and return a score
def evaluate(state):
    if wins(state, COMP):
        score = 1
    elif wins(state, HUMAN):
        score = -1
    else:
        score = 0
    return score

                  # Check if a player has won the game
def wins(state, player):
    win_state = [
        [state[0], state[1], state[2]],
        [state[3], state[4], state[5]],
        [state[6], state[7], state[8]],
        [state[0], state[3], state[6]],
        [state[1], state[4], state[7]],
        [state[2], state[5], state[8]],
        [state[0], state[4], state[8]],
        [state[2], state[4], state[6]]
    ]
    return [player, player, player] in win_state

                  # Check if the game is over
def game_over(state):
    return len(empty_cells(state)) == 0 or wins(state, HUMAN) or wins(state, COMP)

                   # Get the empty cells on the board
def empty_cells(state):
    return [i for i, cell in enumerate(state) if cell == 0]

                  # Check if a move is valid
def valid_move(cell):
    return cell in empty_cells(board)

                  # Set a move on the board for a player
def set_move(cell, player):
    if valid_move(cell):
        board[cell] = player
        return True
    return False

                  # Minimax algorithm to determine the best move for the computer player
def minimax(state, depth, player):
    if player == COMP:
        best = [-1, -1, float('-inf')]
    else:
        best = [-1, -1, float('inf')]

    if game_over(state):
        score = evaluate(state)
        return [-1, -1, score]

    for cell in empty_cells(state):
        state[cell] = player
        score = minimax(state, depth - 1, -player)
        state[cell] = 0
        score[0], score[1] = cell // 3, cell % 3

        if player == COMP:
            if score[2] > best[2]:
                best = score
        else:
            if score[2] < best[2]:
                best = score

    return best

                 # Render the current state of the board
def render(state, c_choice, h_choice):
    symbols = {
        -1: h_choice,
        1: c_choice,
        0: ' '
    }
    for i, cell in enumerate(state):
        if i % 3 == 0 and i != 0:
            print('\n---------')
        print(f'| {symbols[cell]} ', end='')
    print('\n')

                 # Perform the computer's turn
def ai_turn(c_choice, h_choice):
    depth = len(empty_cells(board))
    if game_over(board):
        return

    print(f'Computer turn [{c_choice}]')

    if depth == 9:
        move = random.choice(empty_cells(board))
    else:
        move = minimax(board, depth, COMP)
        move = move[0] * 3 + move[1]

    set_move(move, COMP)
    render(board, c_choice, h_choice)

                   # Perform the human's turn
def human_turn(c_choice, h_choice):
    depth = len(empty_cells(board))
    if game_over(board):
        return

    moves = {
        1: (0, 0), 2: (0, 1), 3: (0, 2),
        4: (1, 0), 5: (1, 1), 6: (1, 2),
        7: (2, 0), 8: (2, 1), 9: (2, 2)
    }

    print(f'Human turn [{h_choice}]')

    while True:
        try:
            move = int(input('Use numpad (1..9): '))
            coord = moves.get(move)
            if coord is None:
                raise ValueError
            if not valid_move(coord[0] * 3 + coord[1]):
                print('Already taken. Try again.')
                continue
        except (EOFError, KeyboardInterrupt):
            print('Bye')
            exit()
        except (ValueError, TypeError):
            print('Wrong choice. Try again.')
            continue
        break

    set_move(coord[0] * 3 + coord[1], HUMAN)
    render(board, c_choice, h_choice)

                # Main game loop
def main():
    h_choice = 'O'
    c_choice = 'X'

    render(board, c_choice, h_choice)

    while not game_over(board):
        human_turn(c_choice, h_choice)
        ai_turn(c_choice, h_choice)

    if wins(board, HUMAN):
        print('YOU WIN!')
    elif wins(board, COMP):
        print('YOU LOSE!')
    else:
        print('DRAW!')

if __name__ == '__main__':
    main()
