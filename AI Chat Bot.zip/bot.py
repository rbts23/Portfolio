import aiml
import os
from tkinter import *
from tkinter.scrolledtext import ScrolledText

# Create a kernel instance
kernel = aiml.Kernel()

# Function to import AIML files from a directory
def import_aiml_files(directory):
    for data in os.listdir(directory):
        if data.endswith(".aiml"):
            aiml_file = os.path.join(directory, data)
            kernel.learn(aiml_file)

# Specify the directory containing AIML files
aiml_directory = r"D:\Rijab\AI chat bot\data"  # Update this to your AIML directory path

# Call the function to import AIML files
import_aiml_files(aiml_directory)

# Create a function to get bot's response
def get_bot_response():
    user_input = entry.get()
    output.insert(END, "User: " + user_input + "\n")
    response = kernel.respond(user_input)
    output.insert(END, "Bot: " + response + "\n", "bot")  # Use the "bot" tag for the response
    entry.delete(0, END)

# Create a GUI window
window = Tk()
window.title("ChatBot")
window.geometry("400x500")
window.configure(bg="#C8A2C8")

# Create a scrolled text widget for the conversation display
output = ScrolledText(window, height=20, width=40, wrap=WORD, bg="#E6E6FA", fg="black")
output.pack()

# Create an entry widget for user input
entry = Entry(window, width=30,fg="black")
entry.insert(0, "Type here")
entry.bind("<FocusIn>", lambda event: entry.delete(0, END))
entry.bind("<FocusOut>", lambda event: entry.insert(0, "Type here"))
entry.pack()

# Create a button to send user input
button = Button(window, text="Send", command=get_bot_response, bg="#FFCB8F", fg="black")
button.pack()
output.tag_configure("bot", background="#FFCB8F")
# Run the GUI main loop
window.mainloop()
